sh run.zsh io.agora.rtc.test.DataStreamTest -channelId  aga1  -sampleRate 16000 -numOfChannels 2 -audioFile short.pcm -videoFile 360p_I420.yuv -height 360 -width 640 -fps 15

