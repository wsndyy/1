# default encryption mode is SM4_128_ECB
sh run.zsh io.agora.rtc.test.SendEncryptedH264Test -channelId aga -userId "1234" -encryptionMode 1 -encryptionKey 111
