sh run.zsh io.agora.rtc.test.Vp8SendTest -channelId  aga   -fps 15 -videoFile test_data/test.vp8.ivf

