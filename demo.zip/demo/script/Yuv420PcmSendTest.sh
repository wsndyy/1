sh run.zsh io.agora.rtc.test.YuvPcmSendTest -channelId  aga  -sampleRate 16000 -numOfChannels 2 -audioFile test_data/send_audio_16k_1ch.pcm -videoFile test_data/360p_I420.yuv -height 360 -width 640 -fps 15

