sh run.zsh io.agora.rtc.test.SendYuvDualStreamTest -channelId  aga -height 288 -width 352 -fps 15 -videoFile test_data/send_video_cif.yuv
