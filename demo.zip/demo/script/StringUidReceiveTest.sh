sh run.zsh io.agora.rtc.test.StringUidReceiveTest -channelId aga -userId test -sampleRate 16000 -numOfChannels 2
