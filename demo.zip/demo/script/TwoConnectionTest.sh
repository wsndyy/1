sh run.zsh io.agora.rtc.test.TwoConnectionTest -stringUid -channelId aga -channelId1 aga1 -userId test -userId1 test1236 -sampleRate 16000 -numOfChannels 2
