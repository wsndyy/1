sh run.zsh io.agora.rtc.test.ReceiveMixedAudioTest -channelId aga -sampleRate 16000 -numOfChannels 2 -userId "1234"
