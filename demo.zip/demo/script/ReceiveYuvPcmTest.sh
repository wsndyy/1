sh run.zsh io.agora.rtc.test.ReceiveYuvPcmTest -channelId  aga  -sampleRate 16000 -numOfChannels 2
