sh run.zsh io.agora.rtc.test.SendH264DualStreamTest -channelId  aga -fps 15 -lowVideoFile test_data/send_video.h264 -highVideoFile received_video.h264
