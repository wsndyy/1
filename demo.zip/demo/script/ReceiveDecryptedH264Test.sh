sh run.zsh io.agora.rtc.test.ReceiveDecryptedH264 -channelId aga -userId "1234" -encryptionMode 1 -encryptionKey 111
