package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.util.Arrays;

import io.agora.rtc.IAudioFrameObserver;
import io.agora.rtc.IVideoEncodedFrameObserver;
import io.agora.rtc.common.FileWriter;

import io.agora.rtc.DefaultRtcConnObserver;
import io.agora.rtc.RtcConnInfo;
import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraVideoEncodedFrameObserver;
import io.agora.rtc.AgoraLocalUser;
import io.agora.rtc.AudioFrame;
import io.agora.rtc.EncodedVideoFrameInfo;
import io.agora.rtc.AudioSubscriptionOptions;
import io.agora.rtc.VideoSubscriptionOptions;
import io.agora.rtc.RtcConnConfig;

import io.agora.rtc.common.SampleLocalUserObserver;
import io.agora.rtc.common.SampleCommon;

public class H264PcmReceiveTest extends AgoraTest {

    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    //  Video stream types.
    public static int VIDEO_STREAM_HIGH = 0;
    public static int VIDEO_STREAM_LOW = 1;


    private String token = AgoraTest.APPID;
    private String userId = "";
    private String channelId = "";
    private String remoteUserId = "";
    private String streamType = "high";
    private String audioFile = "received_audio.pcm";
    private String videoFile = "received_video.h264";
    private int sampleRate = 48000;
    private int numOfChannels = 1;
    private SampleLocalUserObserver localUserObserver;
    private H264FrameReceiver h264FrameReceiver;
    private PcmFrameObserver pcmFrameObserver;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication");
        Option optChannelId = new Option("channelId", true, "Channel Id");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optRemoteUserId = new Option("remoteUserId", true, "The remote user to receive stream from");
        Option optAudioFile = new Option("audioFile", true, "Output audio file");
        Option optVideoFile = new Option("videoFile", true, "Output video file");
        Option optSampleRate = new Option("sampleRate", true, "Sample rate for received audio");
        Option optNumOfChannels = new Option("numOfChannels", true, "Number of channels for received audio");
        Option optStreamType = new Option("streamType", true, "the stream  type");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optRemoteUserId);
        options.addOption(optAudioFile);
        options.addOption(optVideoFile);
        options.addOption(optSampleRate);
        options.addOption(optNumOfChannels);
        options.addOption(optStreamType);


        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        String o_videoFile = commandLine.getOptionValue("videoFile");
        if (o_videoFile != null) {
            videoFile = o_videoFile;
        }
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if (o_userId != null)
            userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        if (o_audioFile != null) audioFile = o_audioFile;
        try {
            sampleRate = Integer.valueOf(commandLine.getOptionValue("sampleRate"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            numOfChannels = Integer.valueOf(commandLine.getOptionValue("numOfChannels"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        H264PcmReceiveTest h264PcmTest = new H264PcmReceiveTest();
        System.out.println(Arrays.toString(args));
        h264PcmTest.handleOptions(args);
        h264PcmTest.sdkTest();
    }

    public void commandLineParserTest() {
        handleOptions(new String[]{"-token", "aabgsdf", "-videoFile", "/sdcard/test.vidoe", "-channelId", "aga"});
        System.out.println("token is " + token);
        System.out.println("videoFile is " + videoFile);
        System.out.println("sampleRate is " + sampleRate);

    }


    public void setup() {
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // service.setSystem.out.printlnFilter(15);
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        service.setLogFile("agorasdk.log",10*1024*1024);
        // Create Agora conection
        AudioSubscriptionOptions audioSubOpt = new AudioSubscriptionOptions();
        audioSubOpt.setBytesPerSample(2 * numOfChannels);
        audioSubOpt.setNumberOfChannels(numOfChannels);
        audioSubOpt.setSampleRateHz(sampleRate);

        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setClientRoleType(CLIENT_ROLE_AUDIENCE);
        ccfg.setAudioSubsOptions(audioSubOpt);
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setEnableAudioRecordingOrPlayout(0);

        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }
        // Subcribe streams from all remote users or specific remote user
        VideoSubscriptionOptions subscriptionOptions = new VideoSubscriptionOptions();
        subscriptionOptions.setEncodedFrameOnly(1);
        if (streamType == "high") {
            subscriptionOptions.setType(0);
        } else if (streamType == "low") {
            subscriptionOptions.setType(1);
        } else {
            return;
        }
        if (remoteUserId == null || remoteUserId.isEmpty()) {
            conn.getLocalUser().subscribeAllAudio();
            conn.getLocalUser().subscribeAllVideo(subscriptionOptions);
        } else {
            conn.getLocalUser().subscribeAudio(remoteUserId);
            conn.getLocalUser().subscribeVideo(remoteUserId, subscriptionOptions);
        }

        conn.registerObserver(new DefaultRtcConnObserver() {
            @Override
            public void onUserJoined(AgoraRtcConn agora_rtc_conn, String user_id) {
                super.onUserJoined(agora_rtc_conn, user_id);
                System.out.println("user joinched : " + user_id);
            }

            @Override
            public void onConnected(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnected(agora_rtc_conn, conn_info, reason);
                System.out.println("connected");
            }

            @Override
            public void onConnecting(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnecting(agora_rtc_conn, conn_info, reason);
                System.out.println("connecting");
            }

            @Override
            public void onConnectionLost(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info) {
                super.onConnectionLost(agora_rtc_conn, conn_info);
                System.out.println("connectlost");
            }

            @Override
            public void onConnectionFailure(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnectionFailure(agora_rtc_conn, conn_info, reason);
                System.out.println("connectionFailure reason: " + reason);
            }
        });

        System.out.println("start connection...");
        // Create local user observer
        localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.getLocalUser().registerObserver(localUserObserver);
        // // Register h264 frame receiver to receive video stream
        h264FrameReceiver = new H264FrameReceiver(videoFile);
        conn.getLocalUser().registerVideoEncodedFrameObserver(new AgoraVideoEncodedFrameObserver(h264FrameReceiver));

        // Register audio frame observer to receive audio stream
        pcmFrameObserver = new PcmFrameObserver(audioFile);
        int ret = conn.getLocalUser().setPlaybackAudioFrameBeforeMixingParameters(numOfChannels, sampleRate);
        if (ret > 0) {
            System.out.printf("setPlaybackAudioFrameBeforeMixingParameters fail ret=%d\n", ret);
            return;
        }
        localUserObserver.setAudioFrameObserver(pcmFrameObserver);

        conn.connect(token, channelId, userId);
        System.out.println("start receiving audio & video data ...");
    }

    public void cleanup() {
        // Unregister audio & video frame observers
        localUserObserver.unsetAudioFrameObserver();
        //localUserObserver.unsetVideoFrameObserver();
        // Disconnect from Agora channel
        int ret = conn.disconnect();
        if (ret != 0) {
            System.out.printf("conn.disconnect fail ret=%d\n", ret);
        }
        System.out.printf("Disconnected from Agora channel successfully\n");
        if(h264FrameReceiver != null){
            h264FrameReceiver.release();
        }
        if(pcmFrameObserver != null){
            pcmFrameObserver.release();
        }
        conn.destroy();
        // Destroy Agora Service
        service.destroy();
        System.out.printf("service destroy successfully\n");

    }

    public static class PcmFrameObserver extends FileWriter implements IAudioFrameObserver {
        public PcmFrameObserver(String outputFilePath) {
            super(outputFilePath);
        }

        @Override
        public int onRecordAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onRecordAudioFrame success");
            return 1;
        }

        @Override
        public int onPlaybackAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onPlaybackAudioFrame success");
            return 1;
        }

        @Override
        public int onMixedAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onMixedAudioFrame success");
            return 1;
        }

        @Override
        public int onEarMonitoringAudioFrame(AgoraLocalUser agora_local_user, AudioFrame frame) {
            return 0;
        }

        @Override
        public int onPlaybackAudioFrameBeforeMixing(AgoraLocalUser agora_local_user, String channel_id, String uid, AudioFrame audioFrame) {
            // Write PCM samples
            System.out.println("onPlaybackAudioFrameBeforeMixing success "+uid);
            int writeBytes = audioFrame.getSamplesPerChannel() * audioFrame.getChannels() * 2;
            writeData(audioFrame.getBuffer(), writeBytes);
            return 1;
        }

        @Override
        public int getObservedAudioFramePosition() {
            return 15;
        }
    }

    class H264FrameReceiver extends FileWriter implements IVideoEncodedFrameObserver {

        public H264FrameReceiver(String path) {
            super(path);
        }

        @Override
        public int onEncodedVideoFrame(AgoraVideoEncodedFrameObserver agora_video_encoded_frame_observer, int uid, byte[] image_buffer, long length, EncodedVideoFrameInfo video_encoded_frame_info) {
            //System.out.println("onEncodedVideoFrame success  " + video_encoded_frame_info.getFrameType());
            writeData(image_buffer, (int) length);
            return 1;
        }
    }
}
