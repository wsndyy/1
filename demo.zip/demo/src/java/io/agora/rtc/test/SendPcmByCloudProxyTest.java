package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.FileInputStream;
import java.io.IOException;

import io.agora.rtc.AgoraLocalAudioTrack;
import io.agora.rtc.Constants;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleLocalUserObserver;

import io.agora.rtc.AgoraAudioPcmDataSender;
import io.agora.rtc.AgoraLocalAudioTrack;
import io.agora.rtc.AgoraMediaNodeFactory;
import io.agora.rtc.AgoraParameter;
import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraService;
import io.agora.rtc.Constants;
import io.agora.rtc.GeneralTest;
import io.agora.rtc.RtcConnConfig;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleCommon;
import io.agora.rtc.common.SampleLocalUserObserver;


public class SendPcmByCloudProxyTest extends AgoraTest {

    static {
        System.loadLibrary("mediautils");
    }

    // audio thread
    // send audio data every 10 ms;
    class PcmSender extends FileSender {
        private AgoraAudioPcmDataSender audioFrameSender;
        private static final int INTERVAL = 50; //ms
        private int channels;
        private int samplerate;
        private int bufferSize = 0;
        private byte[] buffer;
        public PcmSender(String filepath, AgoraAudioPcmDataSender sender,int channels,int samplerate){
            super(filepath, INTERVAL);
            audioFrameSender = sender;
            this.channels = channels;
            this.samplerate = samplerate;
            this.bufferSize = channels * samplerate * 2 * INTERVAL /1000;
            this.buffer = new byte[this.bufferSize];
        }

        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(data == null) return;
            audioFrameSender.send(data,(int)timestamp,sampleRate/(1000/INTERVAL),2,channels,samplerate);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            if(fos != null ){
                try {
                    int size = fos.read(buffer,0,bufferSize);
                    if( size <= 0){
                        reset();
                        return null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return buffer;
        }
    }

    public static int CHANNEL_PROFILE_BROADCASTING = 1;
    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    private String token = AgoraTest.APPID;
    private String channelId = "";
    private String userId = "";
    private String audioFile = "test_data/send_audio_16k_1ch.pcm";
    private int sampleRate = 16000;
    private int numOfChannels = 1;
    private int cloudProxy = 0;
    private String localIP;

    private AgoraLocalAudioTrack customAudioTrack;
    private PcmSender pcmSender;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication / must");
        Option optChannelId = new Option("channelId", true, "Channel Id / must");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optAudioFile = new Option("audioFile", true, "The audio file in raw PCM format to be sent");
        Option optSampleRate = new Option("sampleRate", true, "Sample rate for the PCM file to be sent");
        Option optNumOfChannels = new Option("numOfChannels", true, "Number of channels for the PCM file to be sent");
        Option optCloudProxy = new Option("enableCloudProxy", true, "enableCloudProxy");
        Option optLocalIp = new Option("localIP", true, "Local IP");
        //Option optStringUid = new Option("stringUid", false, "if use string uid, add this arguments");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optAudioFile);
        options.addOption(optSampleRate);
        options.addOption(optNumOfChannels);
        options.addOption(optCloudProxy);
        options.addOption(optLocalIp);

        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if(o_userId != null && !o_userId.isEmpty()) userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        if (o_audioFile != null) audioFile = o_audioFile;
        try {
            sampleRate = Integer.valueOf(commandLine.getOptionValue("sampleRate"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            numOfChannels = Integer.valueOf(commandLine.getOptionValue("numOfChannels"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            cloudProxy = Integer.valueOf(commandLine.getOptionValue("enableCloudProxy"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String o_localIP = commandLine.getOptionValue("localIP");
        if (o_localIP != null) {
            localIP = o_localIP;
        }
    }

    public static void main(String[] args) {
        SendPcmByCloudProxyTest sendPcmByCloudProxyTest = new SendPcmByCloudProxyTest();
        sendPcmByCloudProxyTest.handleOptions(args);
        sendPcmByCloudProxyTest.sdkTest();
    }


    public void setup() {
        // Create Agora service
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        // Create Agora connection
        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setChannelProfile(1);
        ccfg.setClientRoleType(Constants.CLIENT_ROLE_BROADCASTER);
        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }

        GeneralTest.ConnObserver connObserver = new GeneralTest.ConnObserver();
        conn.registerObserver(connObserver);

        SampleLocalUserObserver localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.connect(token, channelId, userId);

        // open the cloudProxy
        if (cloudProxy == 1) {
            AgoraParameter agoraParameter = conn.getAgoraParameter(); // ???
            int ret = agoraParameter.setBool("rtc.enable_proxy", true);
            System.out.printf("set the Cloud_proxy open, ret = %d\n!", ret);
        }

        AgoraMediaNodeFactory mediaNodeFactory = service.createMediaNodeFactory();
        if (mediaNodeFactory == null) {
            System.out.println("Failed to create media node factory!");
            return;
        }
        // Create audio data sender
        AgoraAudioPcmDataSender audioFrameSender = mediaNodeFactory.createAudioPcmDataSender();
        if (audioFrameSender == null) {
            System.out.println("Failed to create audio data sender!");
            return;
        }
        // Create audio track
        customAudioTrack = service.createCustomAudioTrackPcm(audioFrameSender);
        if (audioFrameSender == null) {
            System.out.println("Failed to create audio track !");
            return;
        }


        // Publish audio
        conn.getLocalUser().publishAudio(customAudioTrack);

        // Wait until connected before sending media stream

        // Start sending media data
//        SendAudioThread at = new SendAudioThread(audioFrameSender);
//        // SendVideoThread vt = H264PcmTest.new SendVideoThread(videoFrameSender, exitFlag);
//        at.start();
        pcmSender = new PcmSender(audioFile,audioFrameSender,numOfChannels,sampleRate);
        pcmSender.start();
    }

    public void cleanup() {
        // Unpublish audio & video track
        if (pcmSender != null) pcmSender.release();
        if(conn != null) {
            conn.getLocalUser().unpublishAudio(customAudioTrack);
            // Unregister connection observer
            conn.unregisterObserver();
            // conn.unregisterNetworkObserver();
            // Disconnect from Agora channel
            int ret = conn.disconnect();
            if (ret != 0) {
                System.out.printf("conn.disconnect fail ret=%d\n", ret);
            }
            System.out.printf("Disconnected from Agora channel successfully\n");
            conn.destroy();
        }
        // Destroy Agora Service
        if(service!=null) {
            service.destroy();
        }
    }
}
