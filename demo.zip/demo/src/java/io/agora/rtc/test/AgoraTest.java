package io.agora.rtc.test;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.Map;

import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraService;
import sun.misc.Signal;
import sun.misc.SignalHandler;

public abstract class AgoraTest {
    protected static final String APPID ="aab8b8f5a8cd4469a63042fcfafe7063";
    //ctrl signal
    public static boolean exitFlag = false;
    protected static AgoraService service;
    protected AgoraRtcConn conn;
    class SignalFunc implements SignalHandler {
        public void handle(Signal arg0) {
            System.out.println("catch signal " + arg0);
            exitFlag = true;
        }
    }
    public abstract void setup();
    public abstract void cleanup();

    public void sdkTest(){
        SignalFunc handler = new SignalFunc();
        Signal.handle(new Signal("ABRT"), handler);
        Signal.handle(new Signal("INT"), handler);
        setup();
        while (!exitFlag) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        cleanup();
        System.exit(0);
    }
}
