package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import io.agora.rtc.AgoraLocalVideoTrack;
import io.agora.rtc.AgoraMediaNodeFactory;
import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraService;
import io.agora.rtc.AgoraVideoFrameSender;
import io.agora.rtc.Constants;
import io.agora.rtc.ExternalVideoFrame;
import io.agora.rtc.GeneralTest;
import io.agora.rtc.RtcConnConfig;
import io.agora.rtc.SimulcastStreamConfig;
import io.agora.rtc.VideoDimensions;
import io.agora.rtc.VideoEncoderConfig;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleCommon;
import io.agora.rtc.common.SampleLocalUserObserver;


public class SendYuvDualStreamTest extends AgoraTest {

    static {
        System.loadLibrary("mediautils");
    }

    class Yuv420Sender extends FileSender {
        private AgoraVideoFrameSender imageSender;
        private int height;
        private int width;
        private  byte[] buffer;
        private int bufferLen;
        public Yuv420Sender(String path, int interval, int height, int width, AgoraVideoFrameSender videoEncodedImageSender){
            super(path,interval);
            this.imageSender = videoEncodedImageSender;
            this.height = height;
            this.width = width;
            this.bufferLen = (int)(this.height*this.width*1.5);
            this.buffer = new byte[this.bufferLen];
        }
        private boolean writeData = false;
        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(!writeData){
                File file = new File("piece.yuv");
                FileOutputStream fos = null;
                try {
                    fos = new FileOutputStream(file);
                    fos.write(data);
                    fos.flush();
                    fos.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                writeData = true;
            }
            if(data == null) return;
            System.out.println("height: "+height);
            System.out.println("width: "+width);
            ExternalVideoFrame externalVideoFrame = new ExternalVideoFrame();
            externalVideoFrame.setHeight(height);
            ByteBuffer buffer = ByteBuffer.allocateDirect(data.length);
            buffer.put(data);
            externalVideoFrame.setBuffer(buffer);
            externalVideoFrame.setRotation(0);
            externalVideoFrame.setFormat(Constants.EXTERNAL_VIDEO_FRAME_PIXEL_FORMAT_I420);
            externalVideoFrame.setStride(width);
            externalVideoFrame.setType(Constants.EXTERNAL_VIDEO_FRAME_BUFFER_TYPE_RAW_DATA);
            externalVideoFrame.setTimestamp(timestamp);
            imageSender.send(externalVideoFrame);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            if(fos == null)return null;
            try {
                int size = fos.read(this.buffer,0, bufferLen);
                if(size <= 0){
                    reset();
                    return null;
                }
            } catch (Exception e){
                e.printStackTrace();
            }
            return this.buffer;
        }

        @Override
        public void release() {
            super.release();
        }
    }
    // video thread
//    class SendVideoThread extends Thread {
//        private AgoraVideoEncodedImageSender videoH264FrameSender;
//
//        public SendVideoThread(AgoraVideoEncodedImageSender vfsender, boolean ef) {
//            videoH264FrameSender = vfsender;
//        }
//        public void sendOneH264Frame(int frameRate, , AgoraVideoEncodedImageSender veis) {
//            EncodedVideoFrameInfo videoEncodedFrameInfo;
//            videoEncodedFrameInfo.setRotation(0);
//            videoEncodedFrameInfo.setCodecType(2);
//            videoEncodedFrameInfo.setFramesPerSecond(frameRate);
//            //
//            videoEncodedFrameInfo.setFrameType();
//            veis.send(, , videoEncodedFrameInfo);
//        }
//        public void SampleSendAudioTask(AgoraVideoEncodedImageSender veis) {
//            while (!exitFlag) {
//                HelperH264FileParser h264FileParser = new HelperH264FileParser();
//                h264FileParser.initialize();
//                HelperH264Frame hframe = h264FileParser.getH264Frame();
//                if (hframe) {
//                    sendOneH264Frame((veis));
//                    Thread.sleep(10);
//                }
//            }
//        }
//        public void run() {
//            SampleSendAudioTask(videoH264FrameSender);
//        }
//    }

    public static int CHANNEL_PROFILE_BROADCASTING = 1;
    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    private String token = AgoraTest.APPID;
    private String videoFile = "test_data/send_video_cif.yuv";
    private String channelId = "";
    private String userId = "";
    private int height = 320;
    private int width = 640;
    private int fps = 15;
    private int targetBitrate = 1*1000*1000;
    private AgoraLocalVideoTrack customVideoTrack;
    private Yuv420Sender h264Sender;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication / must");
        Option optChannelId = new Option("channelId", true, "Channel Id / must");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optVideoFile = new Option("videoFile", true, "The video file in YUV420 format to be sent");
        Option optFps = new Option("fps", true, "Target frame rate for sending the video stream");
        Option optBitrate = new Option("bitrate", true, "Target bitrate (bps) for encoding the YUV stream");
        Option optHeight = new Option("height", true, "video height");
        Option optWidth = new Option("width", true, "video width");
        //Option optStringUid = new Option("stringUid", false, "if use string uid, add this arguments");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optVideoFile);
        options.addOption(optFps);
        options.addOption(optHeight);
        options.addOption(optWidth);

        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        String o_videoFile = commandLine.getOptionValue("videoFile");
        System.out.println("videoFile args: "+o_videoFile);
        if (o_videoFile != null) {
            videoFile = o_videoFile;
        }
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if(o_userId != null && !o_userId.isEmpty()) userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        System.out.println("videoFile args: "+o_videoFile);
        if(commandLine.getOptionValue("height") != null) {
            try {
                height = Integer.valueOf(commandLine.getOptionValue("height"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if(commandLine.getOptionValue("width") != null) {
            try {
                width = Integer.valueOf(commandLine.getOptionValue("width"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        try {
            fps = Integer.valueOf(commandLine.getOptionValue("fps"));
        } catch (Exception e) {
            e.printStackTrace();
        }
//        try {
//            targetBitrate = Integer.valueOf(commandLine.getOptionValue("bitrate"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        //stringUid = commandLine.hasOption("stringUid");
    }

    public static void main(String[] args) {
        SendYuvDualStreamTest sendYuvDualStreamTest = new SendYuvDualStreamTest();
        sendYuvDualStreamTest.handleOptions(args);
        sendYuvDualStreamTest.sdkTest();
    }


    public void setup() {
        // Create Agora service
        System.out.println("videoFile :"+videoFile);
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        // Create Agora connection
        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setChannelProfile(1);
        ccfg.setClientRoleType(Constants.CLIENT_ROLE_BROADCASTER);
        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }

        GeneralTest.ConnObserver connObserver = new GeneralTest.ConnObserver();
        conn.registerObserver(connObserver);

        SampleLocalUserObserver localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.connect(token, channelId, userId);


        // Create video frame sender
        AgoraMediaNodeFactory mediaNodeFactory = service.createMediaNodeFactory();
        if (mediaNodeFactory == null) {
            System.out.println("Failed to create media node factory!");
            return;
        }
        AgoraVideoFrameSender videoFrameSender = mediaNodeFactory.createVideoFrameSender();
        if (videoFrameSender == null) {
            System.out.println("Failed to create video frame sender!");
            return;
        }
        // Create video track
        customVideoTrack = service.createCustomVideoTrackFrame(videoFrameSender);
        // Configure video encoder
        VideoEncoderConfig config = new VideoEncoderConfig();
        config.setCodecType(Constants.VIDEO_CODEC_H264);
        config.setDimensions(new VideoDimensions(640,360));
        config.setFrameRate(fps);
        //config.setBitrate(targetBitrate);
        config.setOrientationMode(0);
        customVideoTrack.setVideoEncoderConfig(config);
        // Set the dual_model ahd low_stream
        VideoDimensions lowDimensions = new VideoDimensions(width/2, height/2);
        SimulcastStreamConfig lowStreamConfig = new SimulcastStreamConfig();
        lowStreamConfig.setDimensions(lowDimensions);
        //lowStreamConfig.setBitrate(targetBitrate/2);
        customVideoTrack.enableSimulcastStream(1, lowStreamConfig);
        customVideoTrack.setEnabled(1);
        // Publish audio & video track
//        conn.getLocalUser().publishAudio(customAudioTrack);
        conn.getLocalUser().publishVideo(customVideoTrack);

        // Wait until connected before sending media stream

        // Start sending media data
//        SendAudioThread at = new SendAudioThread(audioFrameSender);
//        // SendVideoThread vt = H264PcmTest.new SendVideoThread(videoFrameSender, exitFlag);
//        at.start();
        System.out.println("height: "+height + "  width: "+width);
        h264Sender = new Yuv420Sender(videoFile,1000/fps,height,width,videoFrameSender);
        h264Sender.start();
    }

    public void cleanup() {
        // Unpublish video track
        conn.getLocalUser().unpublishVideo(customVideoTrack);

        // Unregister connection observer
        conn.unregisterObserver();
        // conn.unregisterNetworkObserver();
        if(h264Sender != null ) h264Sender.release();
        // Disconnect from Agora channel
        int ret = conn.disconnect();
        if (ret != 0) {
            System.out.printf("conn.disconnect fail ret=%d\n", ret);
        }
        System.out.printf("Disconnected from Agora channel successfully\n");
        conn.destroy();
        // Destroy Agora Service
        service.destroy();
    }
}