package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.junit.Test;

import java.util.Arrays;

import io.agora.rtc.IAudioFrameObserver;
import io.agora.rtc.common.FileWriter;

import io.agora.rtc.DefaultRtcConnObserver;
import io.agora.rtc.RtcConnInfo;
import io.agora.rtc.AgoraRtcConn;
import io.agora.rtc.AgoraLocalUser;
import io.agora.rtc.AudioFrame;
import io.agora.rtc.AudioSubscriptionOptions;
import io.agora.rtc.RtcConnConfig;

import io.agora.rtc.common.SampleLocalUserObserver;
import io.agora.rtc.common.SampleCommon;

public class ReceiveMixedAudioTest extends AgoraTest {

    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    //  Video stream types.
    public static int VIDEO_STREAM_HIGH = 0;
    public static int VIDEO_STREAM_LOW = 1;


    private String token = AgoraTest.APPID;
    private String userId = "";
    private String channelId = "";
    private String audioFile = "received_audio.pcm";
    private int sampleRate = 16000;
    private int numOfChannels = 1;
    private SampleLocalUserObserver localUserObserver;
    private PcmFrameObserver pcmFrameObserver;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication");
        Option optChannelId = new Option("channelId", true, "Channel Id");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optAudioFile = new Option("audioFile", true, "Output audio file");
        Option optSampleRate = new Option("sampleRate", true, "Sample rate for received audio");
        Option optNumOfChannels = new Option("numOfChannels", true, "Number of channels for received audio");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optAudioFile);
        options.addOption(optSampleRate);
        options.addOption(optNumOfChannels);


        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if (o_userId != null)
            userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        if (o_audioFile != null) audioFile = o_audioFile;
        try {
            sampleRate = Integer.valueOf(commandLine.getOptionValue("sampleRate"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            numOfChannels = Integer.valueOf(commandLine.getOptionValue("numOfChannels"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ReceiveMixedAudioTest reveiveMixedAudioTest = new ReceiveMixedAudioTest();
        System.out.println(Arrays.toString(args));
        reveiveMixedAudioTest.handleOptions(args);
        reveiveMixedAudioTest.sdkTest();
    }

    @Test
    public void commandLineParserTest() {
        handleOptions(new String[]{"-token", "aabgsdf", "-videoFile", "/sdcard/test.vidoe", "-channelId", "aga"});
        System.out.println("token is " + token);
        System.out.println("sampleRate is " + sampleRate);

    }


    public void setup() {

        // service.setSystem.out.printlnFilter(15);
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }

        // Create Agora conection
        AudioSubscriptionOptions audioSubOpt = new AudioSubscriptionOptions();
        audioSubOpt.setBytesPerSample(2 * numOfChannels);
        audioSubOpt.setNumberOfChannels(numOfChannels);
        audioSubOpt.setSampleRateHz(sampleRate);

        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setClientRoleType(CLIENT_ROLE_AUDIENCE);
        ccfg.setAudioSubsOptions(audioSubOpt);
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setEnableAudioRecordingOrPlayout(0);

        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }
        // Subcribe streams from all remote users or specific remote user

        conn.getLocalUser().subscribeAllAudio();

        conn.registerObserver(new DefaultRtcConnObserver() {
            @Override
            public void onUserJoined(AgoraRtcConn agora_rtc_conn, String user_id) {
                super.onUserJoined(agora_rtc_conn, user_id);
                System.out.println("user joinched : " + user_id);
            }

            @Override
            public void onConnected(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnected(agora_rtc_conn, conn_info, reason);
                System.out.println("connected");
            }

            @Override
            public void onConnecting(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnecting(agora_rtc_conn, conn_info, reason);
                System.out.println("connecting");
            }

            @Override
            public void onConnectionLost(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info) {
                super.onConnectionLost(agora_rtc_conn, conn_info);
                System.out.println("connectlost");
            }

            @Override
            public void onConnectionFailure(AgoraRtcConn agora_rtc_conn, RtcConnInfo conn_info, int reason) {
                super.onConnectionFailure(agora_rtc_conn, conn_info, reason);
                System.out.println("connectionFailure reason: " + reason);
            }
        });

        System.out.println("start connection...");
        // Create local user observer
        localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.getLocalUser().registerObserver(localUserObserver);

        // Register audio frame observer to receive audio stream
        pcmFrameObserver = new PcmFrameObserver(audioFile);
        int ret = conn.getLocalUser().setPlaybackAudioFrameParameters(numOfChannels, sampleRate, 0, sampleRate/100 * numOfChannels);
        if (ret > 0) {
            System.out.printf("setPlaybackAudioFrameParameters fail ret=%d\n", ret);
            return;
        }
        localUserObserver.setAudioFrameObserver(pcmFrameObserver);

        conn.connect(APPID, channelId, userId);
        System.out.println("start receiving audio & video data ...");
    }

    public void cleanup() {
        // Unregister audio frame observers
        localUserObserver.unsetAudioFrameObserver();
        // Disconnect from Agora channel
        int ret = conn.disconnect();
        if (ret != 0) {
            System.out.printf("conn.disconnect fail ret=%d\n", ret);
        }
        System.out.printf("Disconnected from Agora channel successfully\n");
        if(pcmFrameObserver != null){
            pcmFrameObserver.release();
        }
        conn.destroy();
        // Destroy Agora Service
        service.destroy();
    }

    public static class PcmFrameObserver extends FileWriter implements IAudioFrameObserver {
        public PcmFrameObserver(String outputFilePath) {
            super(outputFilePath);
        }

        @Override
        public int onRecordAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onRecordAudioFrame success");
            return 1;
        }

        @Override
        public int onPlaybackAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onPlaybackAudioFrame success");
            int writeBytes = frame.getSamplesPerChannel() * frame.getChannels() * 2;
            writeData(frame.getBuffer(), writeBytes);
            return 1;
        }

        @Override
        public int onMixedAudioFrame(AgoraLocalUser agora_local_user, String channel_id, AudioFrame frame) {
            System.out.println("onMixedAudioFrame success");
            return 1;
        }

        @Override
        public int onEarMonitoringAudioFrame(AgoraLocalUser agora_local_user, AudioFrame frame) {
            return 0;
        }

        @Override
        public int onPlaybackAudioFrameBeforeMixing(AgoraLocalUser agora_local_user, String channel_id, String uid, AudioFrame audioFrame) {
            System.out.println("onPlaybackAudioFrameBeforeMixing success");
            return 1;
        }

        @Override
        public int getObservedAudioFramePosition() {
            return 15;
        }
    }
}
