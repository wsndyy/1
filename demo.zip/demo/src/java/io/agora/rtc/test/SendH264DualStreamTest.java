package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.FileInputStream;

import io.agora.rtc.AgoraLocalVideoTrack;
import io.agora.rtc.AgoraMediaNodeFactory;
import io.agora.rtc.AgoraVideoEncodedImageSender;
import io.agora.rtc.Constants;
import io.agora.rtc.EncodedVideoFrameInfo;
import io.agora.rtc.GeneralTest;
import io.agora.rtc.RtcConnConfig;
import io.agora.rtc.SenderOptions;
import io.agora.rtc.SimulcastStreamConfig;
import io.agora.rtc.VideoDimensions;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleCommon;
import io.agora.rtc.common.SampleLocalUserObserver;
import io.agora.rtc.mediautils.H264Reader;


public class SendH264DualStreamTest extends AgoraTest {

    static {
        System.loadLibrary("mediautils");
    }

    class H264Sender extends FileSender {
        private AgoraVideoEncodedImageSender imageSender;
        private H264Reader h264Reader;
        private int lastFrameType = 0;
        private int height;
        private int width;
        private int fps;
        private int streamType;
        public H264Sender(String path,int interval, int height,int width, AgoraVideoEncodedImageSender videoEncodedImageSender, int streamType){
            super(path,interval,false);
            this.imageSender = videoEncodedImageSender;
            this.h264Reader = new H264Reader(path);
            this.height = height;
            this.width = width;
            this.fps = 1000/interval;
            this.streamType = streamType;
        }
        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(data == null) return;
            EncodedVideoFrameInfo info = new EncodedVideoFrameInfo();
            long currentTime = timestamp;
            info.setFrameType(lastFrameType);
            info.setStreamType(streamType);
            info.setWidth(width);
            info.setHeight(height);
            info.setCodecType(Constants.VIDEO_CODEC_H264);
            info.setCaptureTimeMs(currentTime);
            info.setDecodeTimeMs(currentTime);
            info.setFramesPerSecond(fps);
            info.setRotation(0);
            imageSender.send(data,data.length,info);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            int retry = 0;
            H264Reader.H264Frame frame =  h264Reader.readNextFrame();
            while ( frame == null && retry < 4){
                h264Reader.reset();
                frame = h264Reader.readNextFrame();
                retry ++;
            }
            if( frame != null ) {
                lastFrameType = frame.frameType;
                return frame.data;
            } else {
                return null;
            }
        }

        @Override
        public void release() {
            super.release();
            h264Reader.close();
        }
    }
    // video thread
//    class SendVideoThread extends Thread {
//        private AgoraVideoEncodedImageSender videoH264FrameSender;
//
//        public SendVideoThread(AgoraVideoEncodedImageSender vfsender, boolean ef) {
//            videoH264FrameSender = vfsender;
//        }
//        public void sendOneH264Frame(int frameRate, , AgoraVideoEncodedImageSender veis) {
//            EncodedVideoFrameInfo videoEncodedFrameInfo;
//            videoEncodedFrameInfo.setRotation(0);
//            videoEncodedFrameInfo.setCodecType(2);
//            videoEncodedFrameInfo.setFramesPerSecond(frameRate);
//            //
//            videoEncodedFrameInfo.setFrameType();
//            veis.send(, , videoEncodedFrameInfo);
//        }
//        public void SampleSendAudioTask(AgoraVideoEncodedImageSender veis) {
//            while (!exitFlag) {
//                HelperH264FileParser h264FileParser = new HelperH264FileParser();
//                h264FileParser.initialize();
//                HelperH264Frame hframe = h264FileParser.getH264Frame();
//                if (hframe) {
//                    sendOneH264Frame((veis));
//                    Thread.sleep(10);
//                }
//            }
//        }
//        public void run() {
//            SampleSendAudioTask(videoH264FrameSender);
//        }
//    }

    public static int CHANNEL_PROFILE_BROADCASTING = 1;
    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    private String token = AgoraTest.APPID;
    private String highVideoFile = "test_data/send_video.h264";
    private String lowVideoFile = "test_data/send_video.h264";
    private String channelId = "";
    private String userId = "";
    private int fps = 30;
    private int bwe = 0;
    private AgoraLocalVideoTrack customVideoTrack;
    private H264Sender highH264Sender;
    private H264Sender lowH264Sender;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication / must");
        Option optChannelId = new Option("channelId", true, "Channel Id / must");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optHighVideoFile = new Option("highVideoFile", true, "The high stream video file in h264 format to be sent");
        Option optLowVideoFile = new Option("lowVideoFile", true, "The low stream video file in h264 format to be sent");
        Option optFps = new Option("fps", true, "Target frame rate for sending the video stream");
        Option optBwe = new Option("bwe", true, "show or hide bandwidth estimation info");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optHighVideoFile);
        options.addOption(optLowVideoFile);
        options.addOption(optFps);
        options.addOption(optBwe);

        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        String o_lowVideoFile = commandLine.getOptionValue("lowVideoFile");
        if (o_lowVideoFile != null) {
            lowVideoFile = o_lowVideoFile;
        }
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if(o_userId != null && !o_userId.isEmpty()) userId = o_userId;
        String o_highVideoFile = commandLine.getOptionValue("highVideoFile");
        if (o_highVideoFile != null) highVideoFile = o_highVideoFile;

        try {
            fps = Integer.valueOf(commandLine.getOptionValue("fps"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String o_bwe = commandLine.getOptionValue("bwe");
        if (o_bwe != null) {
            bwe = Integer.valueOf(o_bwe);
        }
        //stringUid = commandLine.hasOption("stringUid");
    }

    public static void main(String[] args) {
        SendH264DualStreamTest sendH264DualStreamTest = new SendH264DualStreamTest();
        sendH264DualStreamTest.handleOptions(args);
        sendH264DualStreamTest.sdkTest();
    }


    public void setup() {
        // Create Agora service
        service = SampleCommon.createAndInitAgoraService(0, 1, 1, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        // Create Agora connection
        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setChannelProfile(1);
        ccfg.setClientRoleType(Constants.CLIENT_ROLE_BROADCASTER);
        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }

        GeneralTest.ConnObserver connObserver = new GeneralTest.ConnObserver();
        conn.registerObserver(connObserver);
//        if (bwe != 0) {
//            conn.registerNetworkObserver(connObserver);
//        }

        SampleLocalUserObserver localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.connect(token, channelId, userId);

        AgoraMediaNodeFactory mediaNodeFactory = service.createMediaNodeFactory();
        if (mediaNodeFactory == null) {
            System.out.println("Failed to create media node factory!");
            return;
        }
        // Create video frame sender
        AgoraVideoEncodedImageSender videoFrameSender = mediaNodeFactory.createVideoEncodedImageSender();
        if (videoFrameSender == null) {
            System.out.println("Failed to create video encoded image sender!");
            return;
        }
        SenderOptions option = new SenderOptions();
        option.setCcMode(Constants.TCC_ENABLED);
        // // Create video track
        customVideoTrack = service.createCustomVideoTrackEncoded(videoFrameSender, option);
        if (customVideoTrack == null) {
            System.out.println("Failed to create video track!");
            return;
        }
        SimulcastStreamConfig lowStreamConfig = new SimulcastStreamConfig();
        lowStreamConfig.setBitrate(65);
        lowStreamConfig.setFramerate(5);
        VideoDimensions dimensions = new VideoDimensions(160, 120);
        lowStreamConfig.setDimensions(dimensions);
        customVideoTrack.enableSimulcastStream(1, lowStreamConfig);

        // Publish audio & video track
        conn.getLocalUser().publishVideo(customVideoTrack);

        // Wait until connected before sending media stream

        // Start sending media data
//        SendAudioThread at = new SendAudioThread(audioFrameSender);
//        // SendVideoThread vt = H264PcmTest.new SendVideoThread(videoFrameSender, exitFlag);
//        at.start();
        highH264Sender = new H264Sender(highVideoFile,1000/fps,0,0,videoFrameSender, Constants.VIDEO_STREAM_HIGH);
        highH264Sender.start();
        lowH264Sender = new H264Sender(lowVideoFile,1000/fps,0,0,videoFrameSender, Constants.VIDEO_STREAM_LOW);
        lowH264Sender.start();
    }

    public void cleanup() {
        // Unpublish audio & video track
        if (conn != null){
            conn.getLocalUser().unpublishVideo(customVideoTrack);

            // Unregister connection observer
            conn.unregisterObserver();
            int ret = conn.disconnect();
            if (ret != 0) {
                System.out.printf("conn.disconnect fail ret=%d\n", ret);
            }
            conn.destroy();
        }
        // conn.unregisterNetworkObserver();
        if(highH264Sender != null ) highH264Sender.release();
        if(lowH264Sender != null ) lowH264Sender.release();
        // Disconnect from Agora channel

        System.out.printf("Disconnected from Agora channel successfully\n");
        // Destroy Agora Service
        if(service != null) {
            service.destroy();
        }
    }
}