package io.agora.rtc.test;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.FileInputStream;
import java.io.IOException;

import io.agora.rtc.AgoraAudioPcmDataSender;
import io.agora.rtc.AgoraLocalAudioTrack;
import io.agora.rtc.AgoraLocalVideoTrack;
import io.agora.rtc.AgoraMediaNodeFactory;
import io.agora.rtc.AgoraVideoEncodedImageSender;
import io.agora.rtc.Constants;
import io.agora.rtc.EncodedVideoFrameInfo;
import io.agora.rtc.GeneralTest;
import io.agora.rtc.RtcConnConfig;
import io.agora.rtc.SenderOptions;
import io.agora.rtc.VideoEncoderConfig;
import io.agora.rtc.common.FileSender;
import io.agora.rtc.common.SampleCommon;
import io.agora.rtc.common.SampleLocalUserObserver;
import io.agora.rtc.mediautils.VideoFrame;
import io.agora.rtc.mediautils.Vp8Reader;


public class Vp8SendTest extends AgoraTest {

    static {
        System.loadLibrary("mediautils");
    }

    // audio thread
    // send audio data every 10 ms;
    class PcmSender extends FileSender {
        private AgoraAudioPcmDataSender audioFrameSender;
        private static final int INTERVAL = 50; //ms
        private int channels;
        private int samplerate;
        private int bufferSize = 0;
        private byte[] buffer;
        public PcmSender(String filepath, AgoraAudioPcmDataSender sender,int channels,int samplerate){
            super(filepath, INTERVAL);
            audioFrameSender = sender;
            this.channels = channels;
            this.samplerate = samplerate;
            this.bufferSize = channels * samplerate * 2 * INTERVAL /1000;
            this.buffer = new byte[this.bufferSize];
        }

        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(data == null) return;
            audioFrameSender.send(data,(int)timestamp,sampleRate/(1000/INTERVAL),2,channels,samplerate);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            if(fos != null ){
                try {
                    int size = fos.read(buffer,0,bufferSize);
                    if( size <= 0){
                        reset();
                        return null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return buffer;
        }
    }

    class Vp8Sender extends FileSender {
        private AgoraVideoEncodedImageSender imageSender;
        private Vp8Reader Vp8Reader;
        private int lastFrameType = 0;
        private int height;
        private int width;
        private int fps;
        public Vp8Sender(String path, int interval, int height, int width, AgoraVideoEncodedImageSender videoEncodedImageSender){
            super(path,interval,false);
            this.imageSender = videoEncodedImageSender;
            this.Vp8Reader = new Vp8Reader(path);
            this.height = height;
            this.width = width;
            this.fps = 1000/interval;
        }
        @Override
        public void sendOneFrame(byte[] data,long timestamp) {
            if(data == null) return;
            EncodedVideoFrameInfo info = new EncodedVideoFrameInfo();
            long currentTime = timestamp;
            info.setFrameType(lastFrameType);
            info.setWidth(width);
            info.setHeight(height);
            info.setCodecType(Constants.VIDEO_CODEC_VP8);
            info.setCaptureTimeMs(currentTime);
            info.setDecodeTimeMs(currentTime);
            info.setFramesPerSecond(fps);
            info.setRotation(0);
            imageSender.send(data,data.length,info);
        }

        @Override
        public byte[] readOneFrame(FileInputStream fos) {
            int retry = 0;
            VideoFrame frame =  Vp8Reader.readNextFrame();
            while ( frame == null && retry < 4){
                Vp8Reader.reset();
                frame = Vp8Reader.readNextFrame();
                retry ++;
            }
            if( frame != null ) {
                lastFrameType = frame.frameType;
                width = frame.width;
                height = frame.height;
                return frame.data;
            } else {
                return null;
            }
        }

        @Override
        public void release() {
            super.release();
            Vp8Reader.close();
        }
    }
    // video thread
//    class SendVideoThread extends Thread {
//        private AgoraVideoEncodedImageSender videoH264FrameSender;
//
//        public SendVideoThread(AgoraVideoEncodedImageSender vfsender, boolean ef) {
//            videoH264FrameSender = vfsender;
//        }
//        public void sendOneH264Frame(int frameRate, , AgoraVideoEncodedImageSender veis) {
//            EncodedVideoFrameInfo videoEncodedFrameInfo;
//            videoEncodedFrameInfo.setRotation(0);
//            videoEncodedFrameInfo.setCodecType(2);
//            videoEncodedFrameInfo.setFramesPerSecond(frameRate);
//            //
//            videoEncodedFrameInfo.setFrameType();
//            veis.send(, , videoEncodedFrameInfo);
//        }
//        public void SampleSendAudioTask(AgoraVideoEncodedImageSender veis) {
//            while (!exitFlag) {
//                HelperH264FileParser h264FileParser = new HelperH264FileParser();
//                h264FileParser.initialize();
//                HelperH264Frame hframe = h264FileParser.getH264Frame();
//                if (hframe) {
//                    sendOneH264Frame((veis));
//                    Thread.sleep(10);
//                }
//            }
//        }
//        public void run() {
//            SampleSendAudioTask(videoH264FrameSender);
//        }
//    }

    public static int CHANNEL_PROFILE_BROADCASTING = 1;
    public static int CLIENT_ROLE_BROADCASTER = 1;
    public static int CLIENT_ROLE_AUDIENCE = 2;

    private String token = AgoraTest.APPID;
    private String videoFile = "test_data/test.vp8.ivf";
    private String channelId = "";
    private String userId = "";
    private String audioFile = "test_data/send_audio_16k_1ch.pcm";
    private int sampleRate = 16000;
    private int numOfChannels = 1;
    private int fps = 30;
    private String localIP;
    //private boolean stringUid = false;
    private int bwe = 0;
    private AgoraLocalAudioTrack customAudioTrack;
    private PcmSender pcmSender;
    private AgoraLocalVideoTrack customVideoTrack;
    private Vp8Sender vp8Sender;
    public void handleOptions(String[] args) {
        Options options = new Options();
        Option optToken = new Option("token", true, "The token for authentication / must");
        Option optChannelId = new Option("channelId", true, "Channel Id / must");
        Option optUserId = new Option("userId", true, "User Id / default is 0");
        Option optAudioFile = new Option("audioFile", true, "The audio file in raw PCM format to be sent");
        Option optVideoFile = new Option("videoFile", true, "The video file in YUV420 format to be sent");
        Option optSampleRate = new Option("sampleRate", true, "Sample rate for the PCM file to be sent");
        Option optNumOfChannels = new Option("numOfChannels", true, "Number of channels for the PCM file to be sent");
        Option optFps = new Option("fps", true, "Target frame rate for sending the video stream");
        Option optBwe = new Option("bwe", true, "show or hide bandwidth estimation info");
        Option optLocalIp = new Option("localIP", true, "Local IP");
        //Option optStringUid = new Option("stringUid", false, "if use string uid, add this arguments");

        options.addOption(optToken);
        options.addOption(optChannelId);
        options.addOption(optUserId);
        options.addOption(optAudioFile);
        options.addOption(optVideoFile);
        options.addOption(optSampleRate);
        options.addOption(optNumOfChannels);
        options.addOption(optFps);
        options.addOption(optBwe);
        options.addOption(optLocalIp);
//        options.addOption(optStringUid);

        CommandLine commandLine = null;
        CommandLineParser parser = new DefaultParser();
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
//            e.printStackTrace();
            System.out.println("unkown option: " + e.getMessage());
        }
        if (commandLine == null) return;
        String o_token = commandLine.getOptionValue("token");
        if (o_token != null) token = o_token;
        String o_videoFile = commandLine.getOptionValue("videoFile");
        if (o_videoFile != null) {
            videoFile = o_videoFile;
        }
        channelId = commandLine.getOptionValue("channelId");
        if (channelId == null) {
            throw new IllegalArgumentException("no channeldId provided !!!");
        }
        String o_userId = commandLine.getOptionValue("userId");
        if(o_userId != null && !o_userId.isEmpty()) userId = o_userId;
        String o_audioFile = commandLine.getOptionValue("audioFile");
        if (o_audioFile != null) audioFile = o_audioFile;
        try {
            sampleRate = Integer.valueOf(commandLine.getOptionValue("sampleRate"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            numOfChannels = Integer.valueOf(commandLine.getOptionValue("numOfChannels"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            fps = Integer.valueOf(commandLine.getOptionValue("fps"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        String o_localIP = commandLine.getOptionValue("localIP");
        if (o_localIP != null) {
            localIP = o_localIP;
        }
        String o_bwe = commandLine.getOptionValue("bwe");
        if (o_bwe != null) {
            bwe = Integer.valueOf(o_bwe);
        }
        //stringUid = commandLine.hasOption("stringUid");
    }

    public static void main(String[] args) {
        Vp8SendTest h264PcmTest = new Vp8SendTest();
        h264PcmTest.handleOptions(args);
        h264PcmTest.sdkTest();
    }


    public void setup() {
        // Create Agora service
        service = SampleCommon.createAndInitAgoraService(0, 1, 0, 0, null);
        if (null == service) {
            System.out.printf("createAndInitAgoraService fail\n");
            return;
        }
        // Create Agora connection
        RtcConnConfig ccfg = new RtcConnConfig();
        ccfg.setAutoSubscribeAudio(0);
        ccfg.setAutoSubscribeVideo(0);
        ccfg.setChannelProfile(1);
        ccfg.setClientRoleType(Constants.CLIENT_ROLE_BROADCASTER);
        conn = service.agoraRtcConnCreate(ccfg);
        if (conn == null) {
            System.out.printf("AgoraService.agoraRtcConnCreate fail\n");
            return;
        }

        GeneralTest.ConnObserver connObserver = new GeneralTest.ConnObserver();
        conn.registerObserver(connObserver);
//        if (bwe != 0) {
//            conn.registerNetworkObserver(connObserver);
//        }
        AgoraMediaNodeFactory mediaNodeFactory = service.createMediaNodeFactory();
        SampleLocalUserObserver localUserObserver = new SampleLocalUserObserver(conn.getLocalUser());
        conn.connect(token, channelId, userId);


        // // Create video frame sender
         AgoraVideoEncodedImageSender videoFrameSender = mediaNodeFactory.createVideoEncodedImageSender();
         SenderOptions option = new SenderOptions();
         option.setCcMode(0);
        // // Create video track
        customVideoTrack = service.createCustomVideoTrackEncoded(videoFrameSender, option);
        // Create audio data sender
        AgoraAudioPcmDataSender audioFrameSender = mediaNodeFactory.createAudioPcmDataSender();
        // Create audio track
        customAudioTrack = service.createCustomAudioTrackPcm(audioFrameSender);

        VideoEncoderConfig config = new VideoEncoderConfig();
        config.setCodecType(Constants.VIDEO_CODEC_VP8);
        customVideoTrack.setVideoEncoderConfig(config);
        // Publish audio & video track
         conn.getLocalUser().publishVideo(customVideoTrack);
         conn.getLocalUser().publishAudio(customAudioTrack);

        // Wait until connected before sending media stream

        // Start sending media data
//        SendAudioThread at = new SendAudioThread(audioFrameSender);
//        // SendVideoThread vt = H264PcmTest.new SendVideoThread(videoFrameSender, exitFlag);
//        at.start();
        vp8Sender = new Vp8Sender(videoFile,1000/fps,0,0,videoFrameSender);
        vp8Sender.start();
        pcmSender = new PcmSender(audioFile,audioFrameSender,numOfChannels,sampleRate);
        pcmSender.start();
    }

    public void cleanup() {
        // Unpublish audio & video track
        if(vp8Sender != null ) vp8Sender.release();
        if(pcmSender != null) pcmSender.release();
        if(conn != null) {
            conn.getLocalUser().unpublishVideo(customVideoTrack);
            conn.getLocalUser().unpublishAudio(customAudioTrack);
            // Unregister connection observer
            conn.unregisterObserver();
            // conn.unregisterNetworkObserver();
            // Disconnect from Agora channel
            int ret = conn.disconnect();
            if (ret != 0) {
                System.out.printf("conn.disconnect fail ret=%d\n", ret);
            }
            System.out.printf("Disconnected from Agora channel successfully\n");
            conn.destroy();
        }
        // Destroy Agora Service
        if(service != null){
            service.destroy();
        }
    }
}
