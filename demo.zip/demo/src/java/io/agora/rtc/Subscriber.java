package io.agora.rtc;

public class Subscriber {
    public static void main(String[] args) {
        
    }
}
